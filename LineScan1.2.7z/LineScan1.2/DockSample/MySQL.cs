﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;
using MySql.Data;
using System.Windows.Forms;


namespace DockSample
{

    class MySQL
    {
        #region SQL
        //连接数据库
        //public static string ConnStr = @"server=localhost; user id=root; password=root20162016; database=eggs; charset=utf8";

        public static String ConnString()
        {
            string Sqlcon = string.Format("server={0};user id={1};password={2};database={3};Charset={4}", "localhost", "root","root20162016", "dbtest","utf8");
            return Sqlcon;
        }

        //打开
        public static MySqlConnection Open_Conn(string ConnString)
        {
            try
            {
                MySqlConnection Conn = new MySqlConnection(ConnString);
                Conn.Open();
                return Conn;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        //执行
        public static MySqlCommand Run_SQL(string SQL, string ConnString)
        {
            try
            {
                MySqlConnection Conn = Open_Conn(ConnString);
                MySqlCommand Cmd = new MySqlCommand(SQL, Conn);
                return Cmd;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        //关闭
        public static void Close_Conn(MySqlConnection Conn)
        {
            if (Conn != null)
            {
                Conn.Close();
                Conn.Dispose();
            }
            GC.Collect();
        }

        #endregion

        #region Function

        //执行
        public static void Execute(string SQL)
        {
            MySqlConnection Conn = Open_Conn(ConnString());
            try
            {
                MySqlCommand Cmd = Run_SQL(SQL, ConnString());
                int result_count = Cmd.ExecuteNonQuery();
                if (result_count >= 1)
                {
                    Console.WriteLine("操作成功！");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Close_Conn(Conn);
            }
        }

        //获取数据
        public static MySqlDataReader Select_DataReader(string SQL)
        {
            MySqlConnection Conn = Open_Conn(ConnString());
            try
            {
                MySqlCommand Cmd = Run_SQL(SQL, ConnString());
                int result_count = Cmd.ExecuteNonQuery();
                if (result_count >= 1)
                {
                    Console.WriteLine("操作成功！");
                }
                MySqlDataReader da1 = Cmd.ExecuteReader();
                return da1;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            finally
            {
                Close_Conn(Conn);
            }
        }

        public static DataTable Select_DataTable(string SQL,string Table_name)
        {
            MySqlConnection Conn = Open_Conn(ConnString());
            try
            {
                MySqlDataAdapter Da = new MySqlDataAdapter(SQL, Conn);
                DataTable dt = new DataTable(Table_name);
                Da.Fill(dt);
                return dt;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            finally
            {
                Close_Conn(Conn);
            }
        }

        public static int Test(string SQL)
        {
            MySqlConnection Conn = Open_Conn(ConnString());
            MySqlCommand Cmd = Run_SQL(SQL, ConnString());
            try
            {
                int count = Convert.ToInt32(Cmd.ExecuteScalar());
                return count;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return 0;
            }
            finally
            {
                Close_Conn(Conn);
            }
        }

        #endregion

    }
}



