﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DockSample
{
    public partial class Loading : System.Windows.Forms.Form
    {
        //public delegate void childclose();
        //public event childclose closefather;

        public Loading()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string temp_Name = txtAccount.Text.Trim ();
            string temp_Password = txtPassword.Text.Trim ();
            string temp_index = listBox1.Text.Trim();
            string SQL =  String.Format("SELECT COUNT(*) FROM dbtest.user1 WHERE iduser='"+ temp_Name+"' and psw='"+ temp_Password+"'and type='"+ temp_index + "'");
            try
            {
                if (MySQL.Test(SQL) >= 1)
                {
                    //MessageBox.Show( "登录成功");
                    this.Close();
                    //this.Hide();
                    //MainForm mainform = new MainForm();
                    // mainform.Show();
                }
                else if(temp_index == "")
                {
                    MessageBox.Show("请选择用户类型！", "登录失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("用户名或密码错误！", "登录失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtAccount.Clear();
                    txtPassword.Clear();
                    this.txtAccount.Focus();
                    return;
                }
            }
            catch (ArgumentException ex_cmd)
            {
                MessageBox.Show(ex_cmd.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Landing_Load(object sender, EventArgs e)        {       }

        private void Landing_FormClosing(object sender, FormClosingEventArgs e)       {      }

        private void Cancel_Click(object sender, EventArgs e)
        {
            //Environment.Exit(0);
            //System.Environment.Exit(0);
            //Application.Exit();//退出整个应用程序
            System.Diagnostics.Process tt = System.Diagnostics.Process.GetProcessById(System.Diagnostics.Process.GetCurrentProcess().Id);
            tt.Kill();//直接杀死与本程序相关的所有进程，有可能会导致数据丢失，但是不会抛出异常。  
        }
    }
}
