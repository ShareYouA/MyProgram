using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Reflection;
using System.Windows.Forms;
using System.IO;
using WeifenLuo.WinFormsUI.Docking;
using DockSample.Customization;

using HalconDotNet;
using MvCamCtrl.NET;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Collections.ObjectModel;
using System.Threading;


namespace DockSample
{
    public partial class Form : System.Windows.Forms.Form
    {
        bool T = false;
        int Number = 0;

        private bool m_bSaveLayout = true;
        private DeserializeDockContent m_deserializeDockContent;
        private Graph grapDoc;
        private Camera cameraDoc;
        private TheLog theLogDoc = new TheLog();
        private ToolBox toolBoxDoc;
        private MySQLAction mySQLActionDoc = new MySQLAction();

        public Form()
        {
            InitializeComponent();

            m_deserializeDockContent = new DeserializeDockContent(GetContentFromPersistString);
            grapDoc = new Graph();
            cameraDoc = new Camera();
            theLogDoc = new TheLog();
            toolBoxDoc = new ToolBox();
            mySQLActionDoc = new MySQLAction();
            //mySQLActionDoc.Insert_Data(DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss-fff") + "  " + "Start");
        }

        #region Methods

        private IDockContent FindDocument(string text)
        {
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                foreach (System.Windows.Forms.Form form in MdiChildren)
                    if (form.Text == text)
                        return form as IDockContent;

                return null;
            }
            else
            {
                foreach (IDockContent content in dockPanel.Documents)
                    if (content.DockHandler.TabText == text)
                        return content;

                return null;
            }
        }

        private DummyDoc CreateNewDocument()
        {
            DummyDoc dummyDoc = new DummyDoc();
            int count = 1;
            
            string text = "Document" + count.ToString();
            while (FindDocument(text) != null)
            {
                count++;          
                text = "Document" + count.ToString();
            }
            dummyDoc.Text = text;
            return dummyDoc;
        }

        private DummyDoc CreateNewDocument(string text)
        {
            DummyDoc dummyDoc = new DummyDoc();
            dummyDoc.Text = text;
            return dummyDoc;
        }

        private Graph CreateNewGrap(string text)
        {
            Graph graphDoc = new Graph();
            graphDoc.Text = text;
            return graphDoc;
        }

        private Camera CreateNewCamera(string text)
        {
            Camera cameraDoc = new Camera();
            cameraDoc.Text = text;
            return cameraDoc;
        }

        private TheLog CreateNewTheLog(string text)
        {
            TheLog theLog = new TheLog();
            theLog.Text = text;
            return theLog;
        }

        private ToolBox CreateNewToolBox(string text)
        {
            ToolBox toolBox = new ToolBox();
            toolBox.Text = text;
            return toolBox;
        }

        private MySQLAction CreateNewmySQLAction(string text)
        {
            MySQLAction mySQLAction = new MySQLAction();
            mySQLAction.Text = text;
            return mySQLAction;
        }

        private void CloseAllDocuments()
        {
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                foreach (System.Windows.Forms.Form form in MdiChildren)
                    form.Close();
            }
            else
            {
                for (int index = dockPanel.Contents.Count - 1; index >= 0; index--)
                {
                    if (dockPanel.Contents[index] is IDockContent)
                    {
                        IDockContent content = (IDockContent)dockPanel.Contents[index];
                        content.DockHandler.Close();
                    }
                }
            }
        }

        private IDockContent GetContentFromPersistString(string persistString)
        {
            if (persistString == typeof(Graph).ToString())
                return grapDoc;
            else if (persistString == typeof(Camera).ToString())
                return cameraDoc;
            else if (persistString == typeof(TheLog).ToString())
                return theLogDoc;
            else if (persistString == typeof(ToolBox).ToString())
                return toolBoxDoc;
            else if (persistString == typeof(MySQLAction).ToString())
                return mySQLActionDoc;
            else
            {
                string[] parsedStrings = persistString.Split(new char[] { ',' });
                if (parsedStrings.Length != 3)
                    return null;

                if (parsedStrings[0] != typeof(DummyDoc).ToString())
                    return null;

                DummyDoc dummyDoc = new DummyDoc();
                if (parsedStrings[1] != string.Empty)
                    dummyDoc.FileName = parsedStrings[1];
                if (parsedStrings[2] != string.Empty)
                    dummyDoc.Text = parsedStrings[2];

                return dummyDoc;
            }
        }

        private void CloseAllContents()
        {
            // we don't want to create another instance of tool window, set DockPanel to null
            //3 m_outputWindow.DockPanel = null;
            grapDoc.DockPanel = null;
            cameraDoc.DockPanel = null;
            // Close all other document windows
            CloseAllDocuments();
        }

        private void SetDockPanelSkinOptions(bool isChecked)
        {
            if (isChecked)
            {
                // All of these options may be set in the designer.
                // This is not a complete list of possible options available in the skin.

                AutoHideStripSkin autoHideSkin = new AutoHideStripSkin();
                autoHideSkin.DockStripGradient.StartColor = Color.AliceBlue;
                autoHideSkin.DockStripGradient.EndColor = Color.Blue;
                autoHideSkin.DockStripGradient.LinearGradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
                autoHideSkin.TabGradient.StartColor = SystemColors.Control;
                autoHideSkin.TabGradient.EndColor = SystemColors.ControlDark;
                autoHideSkin.TabGradient.TextColor = SystemColors.ControlText;
                autoHideSkin.TextFont = new Font("Showcard Gothic", 10);

                dockPanel.Skin.AutoHideStripSkin = autoHideSkin;

                DockPaneStripSkin dockPaneSkin = new DockPaneStripSkin();
                dockPaneSkin.DocumentGradient.DockStripGradient.StartColor = Color.Red;
                dockPaneSkin.DocumentGradient.DockStripGradient.EndColor = Color.Pink;

                dockPaneSkin.DocumentGradient.ActiveTabGradient.StartColor = Color.Green;
                dockPaneSkin.DocumentGradient.ActiveTabGradient.EndColor = Color.Green;
                dockPaneSkin.DocumentGradient.ActiveTabGradient.TextColor = Color.White;

                dockPaneSkin.DocumentGradient.InactiveTabGradient.StartColor = Color.Gray;
                dockPaneSkin.DocumentGradient.InactiveTabGradient.EndColor = Color.Gray;
                dockPaneSkin.DocumentGradient.InactiveTabGradient.TextColor = Color.Black;

                dockPaneSkin.TextFont = new Font("SketchFlow Print", 10);

                dockPanel.Skin.DockPaneStripSkin = dockPaneSkin;
            }
            else
            {
                dockPanel.Skin = new DockPanelSkin();
            }

            //menuItemLayoutByXml_Click(menuItemLayoutByXml, EventArgs.Empty);
        }

        public void SetCtrlWhenOpen()
        {
            bnOpen.Enabled = false;
            bnClose.Enabled = true;
            bnStartGrab.Enabled = true;
            bnStopGrab.Enabled = false;

        }

        public void SetCtrlWhenClose()
        {
            bnOpen.Enabled = true;
            bnClose.Enabled = false;
            bnStartGrab.Enabled = false;
            bnStopGrab.Enabled = false;
            bnCont.Enabled = false;
        }

        public void SetCtrlWhenStartGrab()
        {
            bnStartGrab.Enabled = false;
            bnStopGrab.Enabled = true;
            bnCont.Enabled = true;
        }

        public void SetCtrlWhenStopGrab()
        {
            bnStartGrab.Enabled = true;
            bnStopGrab.Enabled = false;
            bnCont.Enabled = false;
        }

        public void SetCtrlWhenBegin()
        {
            bnStartGrab.Enabled = false;
            bnStopGrab.Enabled = false;
            bnOpen.Enabled = false;
            bnClose.Enabled = false;

        }

        public void SetCtrlWhenWait()
        {
            bnStartGrab.Enabled = false;
            bnStopGrab.Enabled = true;
            bnOpen.Enabled = false;
            bnClose.Enabled = true;
        }

        public void Deal()
        {
            // Local iconic variables 
            HObject ho_Image, ho_Red, ho_Green, ho_Blue;
            HObject ho_Hue, ho_Saturation, ho_Intensity, ho_Regions;
            HObject ho_RegionClosing, ho_ConnectedRegions, ho_SelectedRegions;
            HObject ho_Regions1, ho_RegionClosing1, ho_ConnectedRegions1;
            HObject ho_SelectedRegions1, ho_Rectangle = null, ho_ContCircles = null;

            // Local control variables 
            HTuple hv_Width = null, hv_Height = null, hv_WindowHandle = null;
            HTuple hv_Number = null, hv_Number1 = null, hv_Row = new HTuple();
            HTuple hv_Column = new HTuple(), hv_Phi = new HTuple();
            HTuple hv_Length1 = new HTuple(), hv_Length2 = new HTuple();
            HTuple hv_i = new HTuple(), hv_Radius = new HTuple();

            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Image);
            HOperatorSet.GenEmptyObj(out ho_Red);
            HOperatorSet.GenEmptyObj(out ho_Green);
            HOperatorSet.GenEmptyObj(out ho_Blue);
            HOperatorSet.GenEmptyObj(out ho_Hue);
            HOperatorSet.GenEmptyObj(out ho_Saturation);
            HOperatorSet.GenEmptyObj(out ho_Intensity);
            HOperatorSet.GenEmptyObj(out ho_Regions);
            HOperatorSet.GenEmptyObj(out ho_RegionClosing);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions);
            HOperatorSet.GenEmptyObj(out ho_SelectedRegions);
            HOperatorSet.GenEmptyObj(out ho_Regions1);
            HOperatorSet.GenEmptyObj(out ho_RegionClosing1);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_SelectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_Rectangle);
            HOperatorSet.GenEmptyObj(out ho_ContCircles);
            try
            {
                //Image Acquisition 01: Code generated by Image Acquisition 01
                ho_Image.Dispose();
                ho_Image = cameraDoc.Manage();

                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.ClearWindow(HDevWindowStack.GetActive());
                }
                else
                {
                    HOperatorSet.OpenWindow(-3, -3, grapDoc.hWindowControl1.Width, grapDoc.hWindowControl1.Height, grapDoc.hWindowControl1.HalconWindow, "", "", out hv_WindowHandle);
                    HDevWindowStack.Push(hv_WindowHandle);
                    HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
                    HOperatorSet.SetWindowAttr("background_color", "black");
                }

                ho_Red.Dispose(); ho_Green.Dispose(); ho_Blue.Dispose();
                HOperatorSet.Decompose3(ho_Image, out ho_Red, out ho_Green, out ho_Blue);
                ho_Hue.Dispose(); ho_Saturation.Dispose(); ho_Intensity.Dispose();
                HOperatorSet.TransFromRgb(ho_Red, ho_Green, ho_Blue, out ho_Hue, out ho_Saturation, out ho_Intensity, "hsv");

                ho_Regions.Dispose();
                HOperatorSet.Threshold(ho_Red, out ho_Regions, 80, 240);
                ho_RegionClosing.Dispose();
                HOperatorSet.ClosingRectangle1(ho_Regions, out ho_RegionClosing, 15, 15);
                ho_ConnectedRegions.Dispose();
                HOperatorSet.Connection(ho_RegionClosing, out ho_ConnectedRegions);
                ho_SelectedRegions.Dispose();
                HOperatorSet.SelectShape(ho_ConnectedRegions, out ho_SelectedRegions, "area","and", 10000, 50000);
                HOperatorSet.CountObj(ho_SelectedRegions, out hv_Number);

                ho_Regions1.Dispose();
                HOperatorSet.Threshold(ho_Hue, out ho_Regions1, 80, 200);
                ho_RegionClosing1.Dispose();
                HOperatorSet.ClosingRectangle1(ho_Regions1, out ho_RegionClosing1, 15, 15);
                ho_ConnectedRegions1.Dispose();
                HOperatorSet.Connection(ho_RegionClosing1, out ho_ConnectedRegions1);
                ho_SelectedRegions1.Dispose();
                HOperatorSet.SelectShape(ho_ConnectedRegions1, out ho_SelectedRegions1, "area", "and", 10000, 50000);
                HOperatorSet.CountObj(ho_SelectedRegions1, out hv_Number1);

                if ((int)((new HTuple(hv_Number.TupleGreaterEqual(1))).TupleOr(new HTuple(hv_Number1.TupleGreaterEqual(1)))) != 0)
                {
                    Number += hv_Number;
                    toolBoxDoc.textBox3.Text = "" + Number;

                    if (theLogDoc.richTextBox1.TextLength >= 1000)
                    {
                        theLogDoc.richTextBox1.Clear();
                    }
                    theLogDoc.richTextBox1.Text += DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss-fff") + "  " + "����" + hv_Number + "�����";
                    theLogDoc.richTextBox1.AppendText(Environment.NewLine);
                    grapDoc.textBox1.Text = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss-fff") + "  " + "���ֱ��";

                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Image, HDevWindowStack.GetActive());
                    }

                    if ((int)((new HTuple(hv_Number.TupleGreaterEqual(1))).TupleAnd(new HTuple(hv_Number1.TupleGreaterEqual(
                        1)))) != 0)
                    {
                        HOperatorSet.SmallestRectangle2(ho_SelectedRegions, out hv_Row, out hv_Column,
                            out hv_Phi, out hv_Length1, out hv_Length2);
                        HTuple end_val24 = hv_Number - 1;
                        HTuple step_val24 = 1;
                        for (hv_i = 0; hv_i.Continue(end_val24, step_val24); hv_i = hv_i.TupleAdd(step_val24))
                        {
                            if (HDevWindowStack.IsOpen())
                            {
                                HOperatorSet.SetColor(HDevWindowStack.GetActive(), "red");
                            }
                            ho_Rectangle.Dispose();
                            HOperatorSet.GenRectangle2ContourXld(out ho_Rectangle, hv_Row, hv_Column,
                                                     hv_Phi, hv_Length1, hv_Length2);
                            if (HDevWindowStack.IsOpen())
                            {
                                HOperatorSet.DispObj(ho_Rectangle, HDevWindowStack.GetActive());
                            }
                        }
                    }
                    else if ((int)(new HTuple(hv_Number.TupleGreaterEqual(1))) != 0)
                    {
                        HOperatorSet.SmallestCircle(ho_SelectedRegions, out hv_Row, out hv_Column,
                            out hv_Radius);
                        HTuple end_val30 = hv_Number - 1;
                        HTuple step_val30 = 1;
                        for (hv_i = 0; hv_i.Continue(end_val30, step_val30); hv_i = hv_i.TupleAdd(step_val30))
                        {
                            if (HDevWindowStack.IsOpen())
                            {
                                HOperatorSet.SetColor(HDevWindowStack.GetActive(), "red");
                            }
                            ho_ContCircles.Dispose();
                            HOperatorSet.GenCircleContourXld(out ho_ContCircles, hv_Row.TupleSelect(
                                hv_i), hv_Column.TupleSelect(hv_i), hv_Radius.TupleSelect(hv_i),
                                0, 6.28318, "positive", 1);
                            if (HDevWindowStack.IsOpen())
                            {
                                HOperatorSet.DispObj(ho_ContCircles, HDevWindowStack.GetActive());
                            }
                        }
                    }
                    else
                    {
                        HOperatorSet.SmallestCircle(ho_SelectedRegions, out hv_Row, out hv_Column,
                            out hv_Radius);
                        HTuple end_val36 = hv_Number1 - 1;
                        HTuple step_val36 = 1;
                        for (hv_i = 0; hv_i.Continue(end_val36, step_val36); hv_i = hv_i.TupleAdd(step_val36))
                        {
                            if (HDevWindowStack.IsOpen())
                            {
                                HOperatorSet.SetColor(HDevWindowStack.GetActive(), "green");
                            }
                            ho_ContCircles.Dispose();
                            HOperatorSet.GenCircleContourXld(out ho_ContCircles, hv_Row.TupleSelect(
                                hv_i), hv_Column.TupleSelect(hv_i), hv_Radius.TupleSelect(hv_i),
                                0, 6.28318, "positive", 1);
                            if (HDevWindowStack.IsOpen())
                            {
                                HOperatorSet.DispObj(ho_ContCircles, HDevWindowStack.GetActive());
                            }
                        }
                    }
                }
                else
                {
                    grapDoc.textBox1.Text = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss-fff") + "   ����";

                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_Image, HDevWindowStack.GetActive());
                    }
                }

            }
            catch (HalconException HDevExpDefaultException)
            {
                ho_Image.Dispose();
                ho_Red.Dispose();
                ho_Green.Dispose();
                ho_Blue.Dispose();
                ho_Hue.Dispose();
                ho_Saturation.Dispose();
                ho_Intensity.Dispose();
                ho_Regions.Dispose();
                ho_RegionClosing.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_SelectedRegions.Dispose();
                ho_Regions1.Dispose();
                ho_RegionClosing1.Dispose();
                ho_ConnectedRegions1.Dispose();
                ho_SelectedRegions1.Dispose();
                ho_Rectangle.Dispose();
                ho_ContCircles.Dispose();

                //throw HDevExpDefaultException;
            }
            ho_Image.Dispose();
            ho_Red.Dispose();
            ho_Green.Dispose();
            ho_Blue.Dispose();
            ho_Hue.Dispose();
            ho_Saturation.Dispose();
            ho_Intensity.Dispose();
            ho_Regions.Dispose();
            ho_RegionClosing.Dispose();
            ho_ConnectedRegions.Dispose();
            ho_SelectedRegions.Dispose();
            ho_Regions1.Dispose();
            ho_RegionClosing1.Dispose();
            ho_ConnectedRegions1.Dispose();
            ho_SelectedRegions1.Dispose();
            ho_Rectangle.Dispose();
            ho_ContCircles.Dispose();
        }

        private void Manage1()
        {
            while (T)
            {
                Deal();
            }

        }

        private void menuItemExit()
        {
            Close();
        }

        private void LayoutByCode()
        {
            dockPanel.SuspendLayout(true);

            CloseAllDocuments();

            grapDoc = CreateNewGrap("Graph");
            cameraDoc = CreateNewCamera("Camera");
            theLogDoc = CreateNewTheLog("TheLog");
            toolBoxDoc = CreateNewToolBox("ToolBox");
            mySQLActionDoc = CreateNewmySQLAction("MySQLView");

            toolBoxDoc.Show(dockPanel, DockState.Document);
            theLogDoc.Show(toolBoxDoc.Pane, DockAlignment.Right, 0.75);
            cameraDoc.Show(theLogDoc.Pane, DockAlignment.Top,0.75);
            grapDoc.Show(cameraDoc.Pane, DockAlignment.Right, 0.5);
            mySQLActionDoc.Show(dockPanel, DockState.Document);

            dockPanel.ResumeLayout(true, true);
        }

        #endregion

        #region Event Handlers

        private void MainForm_Load(object sender, System.EventArgs e)
        {
            //��½����
            //Loading flogin = new Loading();
            //flogin.ShowDialog();

            Control.CheckForIllegalCrossThreadCalls = false;

            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.config");

            if (File.Exists(configFile))
                dockPanel.LoadFromXml(configFile, m_deserializeDockContent);
            //��������
            dockPanel.AllowEndUserDocking = !dockPanel.AllowEndUserDocking;
            //��ʾICO
            dockPanel.ShowDocumentIcon = true;
            //Toolbar
            //toolBar.Visible =true ;
        }

        private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.config");
            if (m_bSaveLayout)
                dockPanel.SaveAsXml(configFile);
            else if (File.Exists(configFile))
                File.Delete(configFile);

            //Landing.ActiveForm.Close();
        }
        
        private void exitWithoutSavingLayout_Click(object sender, EventArgs e)
        {
            m_bSaveLayout = false;
            Close();
            m_bSaveLayout = true;
        }

        private void bnEnum_Click(object sender, EventArgs e)
        {
            cameraDoc.bnEnum();
        }

        private void bnOpen_Click(object sender, EventArgs e)
        {
            cameraDoc.bnOpen();
            SetCtrlWhenOpen();
        }

        private void bnStartGrab_Click(object sender, EventArgs e)
        {
            cameraDoc.bnStartGrab();
            SetCtrlWhenStartGrab();
        }

        private void bnStopGrab_Click(object sender, EventArgs e)
        {
            cameraDoc.bnStopGrab();
            SetCtrlWhenStopGrab();
        }

        private void bnClose_Click(object sender, EventArgs e)
        {
            cameraDoc.bnClose();
            SetCtrlWhenClose();
        }

        private void bnCont_Click(object sender, EventArgs e)
        {
            if (T == false)
            {
                T = true;
                bnCont.Text = "ֹͣ";
                Thread th1 = new Thread(Manage1);
                th1.Priority = ThreadPriority.BelowNormal;
                th1.IsBackground = true;//����Ϊ��̨�߳�
                th1.Start();
                SetCtrlWhenBegin();
            }
            else
            {
                T = false;
                bnCont.Text = "ʵʱ����";
                SetCtrlWhenWait();
                theLogDoc.richTextBox1.Text += DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss-fff") + "  " + "ȱ����Ϣ�Ѵ������ݿ�";
            }
        }

        private void LayOut_Click(object sender, EventArgs e)
        {
            LayoutByCode();
        }

        private void Ա����ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mySQLActionDoc.Activate();
            mySQLActionDoc.Employer_view();
        }

        private void ������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mySQLActionDoc.Activate();
            mySQLActionDoc.Export();
        }

        private void ɾ��ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string temp_id = toolStripTextBox1.Text;
            mySQLActionDoc.Delect(temp_id);
        }

        private void ��־��ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mySQLActionDoc.Activate();
            mySQLActionDoc.Testresult_view();
        }
        #endregion

    }
}