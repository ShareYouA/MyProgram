﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using System.IO;

namespace DockSample
{
    public partial class MySQLAction : DockContent
    {
        public MySQLAction()
        {
            InitializeComponent();
        }

        private void Fill_data()
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
        
        private string[] Sql()
        {
            string[] temp = new string[9];
            temp[0] = String.Format("SELECT * FROM dbtest.user1");
            temp[1] = String.Format("SELECT * FROM dbtest.inputtest");
            temp[2] = "INSERT INTO `dbtest`.`inputtest` (`inputStrings`) VALUES ('{0}')";
            temp[5] = String.Format("DELETE FROM  dbtest.user1  WHERE  id=");
            temp[7] = String.Format("SELECT COUNT(*) FROM  dbtest.user1  WHERE  id=");
            return temp;
        }
        
        public static implicit operator MySQLAction(TheLog v)
        {
            throw new NotImplementedException();
        }

        public void Employer_view()
        {
            Fill_data();
            DataTable da = MySQL.Select_DataTable(Sql()[0], "dbtest.user1");
            dataGridView1.DataSource = da;//设置数据源，用于填充控件中的项的值列表
            //dataGridView1.RowTemplate.Height = 200;
            //dataGridView1.DataBind();//将控件及其所有子控件绑定到指定的数据源
        }

        public void Testresult_view()
        {
            Fill_data();
            DataTable da = MySQL.Select_DataTable(Sql()[1], "dbtest.inputtest");
            dataGridView1.DataSource = da;
        }

        public void Insert_Data(string str)
        {
            String SQL = String.Format(Sql()[2] , str);
            MySQL.Execute(SQL);
        }

        public void Daytest_view(string num)
        {
            int a = Test_table(num);
            if (a >= 1)
            {
                string Sql1 = (Sql()[2] + num);
                String SQL = String.Format(Sql1);
                Fill_data();
                DataTable da = MySQL.Select_DataTable(SQL, Sql1);
                dataGridView1.DataSource = da;
            }
            else
            {
                MessageBox.Show("  请输入正确日期！  ");
            }
        }

        public void Monthtest_view()
        {
            Fill_data();
            DataTable da = MySQL.Select_DataTable(Sql()[3], "eggs.daytest_table1");
            dataGridView1.DataSource = da;
        }

        public void Select_view(string id)
        {     
            String SQL = String.Format(Sql()[4]+id);
            Fill_data();
            DataTable da = MySQL.Select_DataTable(SQL, "eggs.employeeinf_table");
            dataGridView1.DataSource = da;
        }

        public void Delect(string id)
        {
            try
            {
                int a = Test(id);
                if (a >= 1)
                {
                    String SQL = (Sql()[5] + id);
                    MySQL.Execute(SQL);
                    MessageBox.Show("  删除成功！  ");
                }
                else if (id == "")
                {
                    //string name = Convert.ToString(dataGridView1.SelectedRows[0].Cells[1].Value);
                    for (int i = this.dataGridView1.SelectedRows.Count; i > 0; i--)
                    {
                        string id1 = Convert.ToString(dataGridView1.SelectedRows[i - 1].Cells[0].Value);
                        dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[i - 1].Index);
                        string SQL = (Sql()[5] + id1);
                        MySQL.Execute(SQL);
                    }
                }
                else
                {
                    MessageBox.Show("  请输入正确id！  ");
                }
            }
            catch (Exception )
            {
                 MessageBox.Show("  请输入正确id！  ");
            }
        }

        public void Creat_lable(string num)
        {
            int a = Test_table(num);
            if (a == 0)
            {
                string SQL = String.Format(Sql()[6], num);
                MySQL.Execute(SQL);
                MessageBox.Show("  创建成功！  ");
            }
            else
            {
                MessageBox.Show("  该表已存在！  ");
            }
        }

        public int Test(string id)
        {
            string Sql1 = (Sql()[7] + id);
            String SQL = String.Format(Sql1);
            int a = MySQL.Test(SQL);
            return a;
        }

        public int Test_table(string num)
        {
            String SQL = String.Format(Sql()[8], num);
            int a = MySQL.Test(SQL);
            return a;
        }

        public void Export()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Excel files (*.xls)|*.xls",
                FilterIndex = 0,
                RestoreDirectory = true,
                CreatePrompt = true,
                Title = "导出Excel文件到"
            };

            DateTime now = DateTime.Now;
            saveFileDialog.FileName = now.Year.ToString().PadLeft(2)
            + now.Month.ToString().PadLeft(2, '0')
            + now.Day.ToString().PadLeft(2, '0') + "-"
            + now.Hour.ToString().PadLeft(2, '0')
            + now.Minute.ToString().PadLeft(2, '0')
            + now.Second.ToString().PadLeft(2, '0');
            saveFileDialog.ShowDialog();

            Stream myStream = saveFileDialog.OpenFile();
            StreamWriter sw = new StreamWriter(myStream, System.Text.Encoding.GetEncoding("gb2312"));
            string str = "";
            try
            {
                //写标题     
                for (int i = 0; i < this.dataGridView1.ColumnCount; i++)
                {
                    if (i > 0)
                    {
                        str += "\t";
                    }
                    str += this.dataGridView1.Columns[i].HeaderText;
                }
                sw.WriteLine(str);
                //写内容   
                for (int j = 0; j < this.dataGridView1.Rows.Count; j++)
                {
                    string tempStr = "";
                    for (int k = 0; k < this.dataGridView1.Columns.Count; k++)
                    {
                        if (k > 0)
                        {
                            tempStr += "\t";
                        }
                        tempStr += this.dataGridView1.Rows[j].Cells[k].Value.ToString();
                    }
                    sw.WriteLine(tempStr);
                }
                sw.Close();
                myStream.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                sw.Close();
                myStream.Close();
            }
        }      

    }
}
